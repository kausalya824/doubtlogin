﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace doubtlogin
{
    public partial class questionform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                if (Request.QueryString["type"] == "Kannada")
                {
                    lblSubject.Text = "Kannada";
                }

                if (Request.QueryString["type"] == "English")
                {
                    lblSubject.Text = "English";
                }
                if (Request.QueryString["type"] == "Hindi")
                {
                    lblSubject.Text = "Hindi";
                }
                if (Request.QueryString["type"] == "Maths")
                {
                    lblSubject.Text = "Maths";
                }
                if (Request.QueryString["type"] == "maths")
                {
                    lblSubject.Text = "maths";
                }
                if (Request.QueryString["type"] == "Socail science")
                {
                    lblSubject.Text = "Socail science";
                }
                if (Request.QueryString["type"] == "Science")
                {
                    lblSubject.Text = "Science";
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string mess = TextBox1.Text;
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + mess + "');", true);
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedItem.Text == "Others")
            {
                TextBox1.Visible = true;
                Label1.Visible = true;
            }
            else
            {
                TextBox1.Visible = false;
                Label1.Visible = false;
            }
        }
    }
}